<?php

class Model_Contact extends ORM
{
	
	//protected $_table_name = 'strange_tablename';

	//protected $_primary_key = 'strange_pkey';


}